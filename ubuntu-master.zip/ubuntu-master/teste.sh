#!/bin/bash
#Meu Primeiro Script

#Listando os diretórios do Linux
ls -lha /
read
clear

#Atualizando o Apt ou Apt-Get
apt update
echo "Listas atualizadas!!!"
read
cls

#Desligando o servidor
shutdown -r now
