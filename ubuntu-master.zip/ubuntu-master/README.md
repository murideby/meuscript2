# ubuntu
Scripts de automatização de instalação de serviços
